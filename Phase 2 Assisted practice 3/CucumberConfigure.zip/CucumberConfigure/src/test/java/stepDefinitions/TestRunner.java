package stepDefinitions;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources",
    glue = "stepDefinitions"
)
public class TestRunner {
    // This class will be empty as it is used to run Cucumber tests.
    // Cucumber will automatically discover and execute the tests based on the provided options.
}
