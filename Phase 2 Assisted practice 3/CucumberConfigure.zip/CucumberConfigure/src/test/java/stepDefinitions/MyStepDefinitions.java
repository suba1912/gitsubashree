package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyStepDefinitions {

    @Given("I want to write a step with name1")
    public void i_want_to_write_a_step_with_name1() {
        // Implementation for the step with name1
        System.out.println("Step with name1");
    }

    @When("I check for the {int} in step")
    public void i_check_for_the_in_step(Integer intValue) {
        // Implementation for the step with integer parameter
        System.out.println("Checking for " + intValue + " in step");
    }

    @Given("I want to write a step with name2")
    public void i_want_to_write_a_step_with_name2() {
        // Implementation for the step with name2
        System.out.println("Step with name2");
    }

    // ... other steps ...
    @Given("I want to write a step with precondition")
    public void i_want_to_write_a_step_with_precondition() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @Given("some other precondition")
    public void some_other_precondition() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }


    @When("I complete action")
    public void i_complete_action() {
        // Implementation for completing action
        System.out.println("Completing action");
    }

    @When("some other action")
    public void some_other_action() {
        // Implementation for some other action
        System.out.println("Some other action");
    }

    @When("yet another action")
    public void yet_another_action() {
        // Implementation for yet another action
        System.out.println("Yet another action");
    }

    @Then("I validate the outcomes")
    public void i_validate_the_outcomes() {
        // Implementation for validating outcomes
        System.out.println("Validating outcomes");
    }

    @Then("check more outcomes")
    public void check_more_outcomes() {
        // Implementation for checking more outcomes
        System.out.println("Checking more outcomes");
    }

    // Scenario Steps
    @Then("I verify the success in step")
    public void i_verify_the_success_in_step() {
        // Implementation for verifying success in step
        System.out.println("Verifying success in step");
    }

    @Then("I verify the Fail in step")
    public void i_verify_the_fail_in_step() {
        // Implementation for verifying fail in step
        System.out.println("Verifying fail in step");
    }
}
