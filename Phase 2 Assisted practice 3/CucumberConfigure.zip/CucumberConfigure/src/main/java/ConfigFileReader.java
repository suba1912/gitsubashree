import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigFileReader {
    private Properties properties;

    public ConfigFileReader() {
        properties = new Properties();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("Configuration.properties")) {
            properties.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getReportConfigPath() {
        String reportConfigPath = properties.getProperty("reportConfigPath");
        if(reportConfigPath != null) {
			return reportConfigPath;
		} else {
			throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key: reportConfigPath");
		}
    }
}

