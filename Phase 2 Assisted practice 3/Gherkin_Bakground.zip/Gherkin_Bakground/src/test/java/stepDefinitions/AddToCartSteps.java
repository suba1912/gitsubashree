package stepDefinitions;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddToCartSteps {

    @Given("the User is logged in")
    public void theUserIsLoggedIn() {
        // Implementation for user login
        System.out.println("User is logged in");
    }

    @Given("User searched for Lenovo Laptop")
    public void userSearchedForLenovoLaptop() {
        // Implementation for searching
        System.out.println("User searched for Lenovo Laptop");
    }

    @When("Add the first laptop that appears in the search result to the basket")
    public void addToBasket() {
        // Implementation for adding to basket
        System.out.println("Adding the first laptop to the basket");
    }

    @Then("I verify the success in step")
    public void verifySuccess() {
        // Implementation for success verification
        System.out.println("Verification of success in step");
    }
}
