package stepdefinitions;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class StepDefinitions {

    @When("I fill {string} with {string}")
    public void i_fill_with(String element, String value) {
        // Implement the code to fill the element with the specified value
        // For example, if you're working with a web page, you might use Selenium:
        // driver.findElement(By.id(element)).sendKeys(value);
    }

    @Then("I click {string}")
    public void i_click(String element) {
        // Implement the code to click on the specified element
        // For example, if you're working with a web page, you might use Selenium:
        // driver.findElement(By.id(element)).click();
    }

    @Then("I follow {string} link")
    public void i_follow_link(String link) {
        // Implement the code to follow the specified link
        // For example, if you're working with a web page, you might use Selenium:
        // driver.findElement(By.linkText(link)).click();
    }
    @Then("She follow {string} link")
    public void she_follow_link(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("He follow {string} link")
    public void he_follow_link(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("User follow {string} link")
    public void user_follow_link(String string) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }


    // Implement other step definitions in a similar manner
}
