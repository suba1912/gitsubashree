package com.gherkinCommentsAndTags;
import org.junit.runner.RunWith;

import io.cucumber.core.cli.Main;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources",
    glue = "stepdefinitions",
    plugin = {"pretty", "json:target/output.json", "html:target/html"},
    tags = "@tag or @tag1"
)
public class TestRunner {
    public static void main(String[] args) {
        Main.main(args);
    }
}