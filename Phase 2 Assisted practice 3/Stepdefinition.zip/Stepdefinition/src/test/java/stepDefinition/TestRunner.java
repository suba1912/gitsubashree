package stepDefinition;
import io.cucumber.core.cli.Main;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/Features",
        glue = "stepDefinition",
        plugin = {"pretty", "html:target/cucumber-reports"}
)
public class TestRunner {
    public static void main(String[] args) {
        Main.main(args);
    }
}
