package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class StepDefinitions {

    @Given("User is on Home Page")
    public void user_is_on_home_page() {
        // Implementation to navigate to the home page
    }

    @When("User Navigate to Login Page")
    public void user_navigate_to_login_page() {
        // Implementation to navigate to the login page
    }

    @When("User enters UserName and Password")
    public void user_enters_user_name_and_password() {
        // Implementation to enter username and password
    }

    @Then("Message displayed Login Successfully")
    public void message_displayed_login_successfully() {
        // Implementation for verifying login success message
    }

    @When("User LogOut from the Application")
    public void user_log_out_from_the_application() {
        // Implementation for logging out from the application
    }

    @Then("Message displayed Logout Successfully")
    public void message_displayed_logout_successfully() {
        // Implementation for verifying logout success message
    }
}
