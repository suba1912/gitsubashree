package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.concurrent.TimeUnit;

public class Test_Steps {
    public static WebDriver driver;

    @Given("^User is on Home Page$")
    public void user_is_on_Home_Page() {
        // Set the path to GeckoDriver
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\USER\\eclipse -workspace-cucumber\\Stepdefinition\\drivers\\geckodriver.exe");

        // Initialize FirefoxDriver
        driver = new FirefoxDriver();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://www.amazon.com");
    }

    @When("^User Navigate to LogIn Page$")
    public void user_Navigate_to_LogIn_Page() throws Throwable {
        // Use a more reliable selector
        driver.findElement(By.id("account")).click();
    }

    @When("^User enters UserName and Password$")
    public void user_enters_UserName_and_Password() throws Throwable {
        // Use explicit wait or other synchronization mechanisms instead of implicit wait
        // to ensure elements are present before interacting with them
        driver.findElement(By.id("log")).sendKeys("testuser_1");
        driver.findElement(By.id("pwd")).sendKeys("Test@123");
        driver.findElement(By.id("login")).click();
    }

    @Then("^Message displayed Login Successfully$")
    public void message_displayed_Login_Successfully() throws Throwable {
        // Consider using assertions to verify the expected outcome
        System.out.println("Login Successfully");
    }

    @When("^User LogOut from the Application$")
    public void user_LogOut_from_the_Application() throws Throwable {
        // Use a more reliable selector
        driver.findElement(By.id("account_logout")).click();
    }

    @Then("^Message displayed Logout Successfully$")
    public void message_displayed_Logout_Successfully() throws Throwable {
        // Consider using assertions to verify the expected outcome
        System.out.println("LogOut Successfully");
        driver.quit(); // Close the browser after logging out
    }

    @When("^User Navigate to Login Page$")
    public void user_navigate_to_login_page() {
        // Add code to simulate user navigation to the login page
        driver.findElement(By.id("your_login_page_element_id")).click();
    }
}
