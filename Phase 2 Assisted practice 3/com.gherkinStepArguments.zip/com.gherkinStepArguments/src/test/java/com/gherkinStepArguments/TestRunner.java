package com.gherkinStepArguments;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue = "com.gherkinstepArgument",
        plugin = {"pretty", "html:target/cucumber-reports", "html:target/cucumber-custom-report.html"},
        tags = "@CustomReport"
)
public class TestRunner {
}
