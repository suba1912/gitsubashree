package com.gherkinStepArguments;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PasswordResetSteps {

    @Given("I ask to reset my password")
    public void i_ask_to_reset_my_password() {
        // Implement the code to initiate the password reset
        // For example, trigger a password reset request in your application
    }

    @When("users request to reset their passwords")
    public void users_request_to_reset_their_passwords(io.cucumber.datatable.DataTable dataTable) {
        // Implement the code to process password reset requests
        // You can use the DataTable parameter to access the table data if needed
    }

   
        // ... existing step definitions ...
    @Then("I should receive an email with:")
    public void i_should_receive_an_email_with(String docString) {
        // Implement the code to verify the email content
        // 'docString' contains the content specified in the feature file
        // For example, you can assert or validate the email content
        // If the step is supposed to be pending, you can update the logic accordingly
        // throw new io.cucumber.java.PendingException();
    }
    }
