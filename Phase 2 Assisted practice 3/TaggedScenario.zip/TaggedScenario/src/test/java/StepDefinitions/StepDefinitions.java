package StepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions {

    @When("I open the {string} website")
    public void i_open_the_website(String website) {
        // Implementation to open the specified website
        System.out.println("Opening the website: " + website);
        // Add your Selenium WebDriver code to open the website here
    }

    @Then("I find the first and last name and print the html")
    public void i_find_the_first_and_last_name_and_print_the_html() {
        // Implementation to find the first and last name and print HTML
        System.out.println("Finding the first and last name and printing HTML");
        // Add your Selenium WebDriver code to locate elements and print HTML here
    }

    @Then("I find menu and print the html")
    public void i_find_menu_and_print_the_html() {
        // Implement code to find menu and print HTML
        System.out.println("Finding menu and printing HTML");
    }

    @Then("I find button and print the html")
    public void i_find_button_and_print_the_html() {
        // Implement code to find button and print HTML
        System.out.println("Finding button and printing HTML");
    }

    @Then("I find radio button male and print the html")
    public void i_find_radio_button_male_and_print_the_html() {
        // Implement code to find radio button male and print HTML
        System.out.println("Finding radio button male and printing HTML");
    }
}
