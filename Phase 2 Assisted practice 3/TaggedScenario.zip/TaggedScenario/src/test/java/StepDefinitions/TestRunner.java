package StepDefinitions; 
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources", // Path to your feature files
    glue = "stepdefinition",          // Package where your step definitions are located
    plugin = {"pretty", "html:target/cucumber-reports"}, // Report configurations
    tags = "@slow",                    // Specify the tags for scenarios to run
    dryRun = true                      // Fail if there are undefined or pending steps
)
public class TestRunner {
}
