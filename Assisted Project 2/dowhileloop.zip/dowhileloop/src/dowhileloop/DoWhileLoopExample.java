package dowhileloop;

public class DoWhileLoopExample {
	public static void main(String[] args) {
        // Initialize variables
        int sum = 0;
        int i = 1;

        // Do-while loop to calculate the sum of integers from 1 to 5
        do {
            sum += i; // Add current value of i to the sum
            i++;      // Increment i for the next iteration
        } while (i <= 6);

        // Print the result
        System.out.println("Sum of integers from 1 to 6: " + sum);
    }
}

