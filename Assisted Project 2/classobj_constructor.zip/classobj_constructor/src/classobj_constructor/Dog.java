package classobj_constructor;

public class Dog {
	 String breed;
	   int age;
	   String color;
void hungry(String a, int n,String b) {
	System.out.println(n);
	System.out.println(a);
	System.out.println(b);
}
void sleeping() {
}}
