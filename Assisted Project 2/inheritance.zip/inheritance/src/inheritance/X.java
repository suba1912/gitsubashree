package inheritance;

public class X {
	public void methodX()
	   {
	     System.out.println("Class X method");
	   }
	}
