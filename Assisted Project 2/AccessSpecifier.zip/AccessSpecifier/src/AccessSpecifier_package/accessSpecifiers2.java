package AccessSpecifier_package;

public class accessSpecifiers2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				//private
				System.out.println("Private Access Specifier");
				priaccessspecifier  obj = new priaccessspecifier(); 
		        //trying to access private method of another class 
		        //obj.display();

			}
		}

