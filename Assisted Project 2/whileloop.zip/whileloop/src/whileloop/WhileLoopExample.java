package whileloop;

public class WhileLoopExample {
	public static void main(String[] args) {
        // Initialize variables
        int sum = 0;
        int i = 1;

        // While loop to calculate the sum of integers from 1 to 5
        while (i <= 5) {
            sum += i; // Add current value of i to the sum
            i++;      // Increment i for the next iteration
        }

        // Print the result
        System.out.println("Sum of integers from 1 to 5: " + sum);
    }
}

