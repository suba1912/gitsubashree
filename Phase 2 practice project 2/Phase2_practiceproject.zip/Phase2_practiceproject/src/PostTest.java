import org.junit.Assert;
import org.junit.Test;

public class PostTest {

    @Test
    public void testCreatePost() {
        User user = new User("test_user", "password123");
        Post post = user.createPost("This is a test post.");
        Assert.assertEquals("This is a test post.", post.getContent());
    }

    @Test
    public void testLikePost() {
        User user = new User("test_user", "password123");
        Post post = new Post("Test post by another user");
        user.likePost(post);
        Assert.assertTrue(user.hasLiked(post));
    }
}

