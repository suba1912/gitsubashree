public class Result {
    private String content;
    private int rank;

    public Result(String content, int rank) {
        this.content = content;
        this.rank = rank;
    }

    public String getContent() {
        return content;
    }

    public int getRank() {
        return rank;
    }
}
