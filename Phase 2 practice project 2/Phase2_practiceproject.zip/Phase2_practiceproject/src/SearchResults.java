import java.util.List;

public class SearchResults {
    private List<Result> results;

    public SearchResults(List<Result> results) {
        this.results = results;
    }

    public List<Result> getResults() {
        return results;
    }
}
