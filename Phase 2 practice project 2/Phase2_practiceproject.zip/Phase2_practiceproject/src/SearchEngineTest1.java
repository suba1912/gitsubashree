import org.junit.Assert;
import org.junit.Test;

public class SearchEngineTest1 {

    @Test
    public void testSearchAlgorithm() {
        SearchEngine searchEngine = new SearchEngine();
        String query = "Test query";
        SearchResults results = searchEngine.search(query);
        
        // Assuming rank attribute is present in results
        Assert.assertTrue(results.getResults().get(0).getRank() > results.getResults().get(results.getResults().size() - 1).getRank());
    }
}

