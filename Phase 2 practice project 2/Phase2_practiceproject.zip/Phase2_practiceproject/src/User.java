
import java.util.ArrayList;
import java.util.List;

public class User {
    private String username;
    private String password;
    private List<Post> likedPosts;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.likedPosts = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public Post createPost(String content) {
        // Your create post logic here
        return new Post(content);
    }

    public void likePost(Post post) {
        // Your like post logic here
        likedPosts.add(post);
    }

    public boolean hasLiked(Post post) {
        // Your has liked logic here
        return likedPosts.contains(post);
    }
    public boolean login() {
        // Simulate a simple login logic (replace this with your actual login logic)
        String validUsername = "test_user";
        String validPassword = "password123";

        return username.equals(validUsername) && password.equals(validPassword);
    }
}