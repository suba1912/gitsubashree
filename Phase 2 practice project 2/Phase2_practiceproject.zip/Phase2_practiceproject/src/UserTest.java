import org.junit.Assert;
import org.junit.Test;

public class UserTest {

    @Test
    public void testValidLogin() {
        // Simulate a valid login
        User user = new User("test_user", "password123");
        boolean loginResult = user.login();
        Assert.assertTrue("Login failed for valid credentials", loginResult);
    }

    @Test
    public void testInvalidLogin() {
        // Simulate an invalid login
        User user = new User("test_user", "invalid_password");
        boolean loginResult = user.login();
        Assert.assertFalse("Login succeeded for invalid credentials", loginResult);
    }
}

