import java.util.List;

public class SearchEngine {

    public SearchResults search(String query) {
        // Implement your search algorithm here
        // This is a simplified example, and you should replace it with your actual search logic
        List<Result> resultsList = performSearch(query);

        // Assuming you have a SearchResults class
        return new SearchResults(resultsList);
    }

    // Replace this method with your actual search logic
    private List<Result> performSearch(String query) {
        // Your search logic goes here
        // This is just a placeholder, replace it with your actual search implementation
        return List.of(new Result("Result 1", 3), new Result("Result 2", 1), new Result("Result 3", 2));
    }
}
