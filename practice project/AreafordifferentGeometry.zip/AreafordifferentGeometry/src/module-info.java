/**
 * 
 */
/**
 * 
 */
module AreafordifferentGeometry {
}