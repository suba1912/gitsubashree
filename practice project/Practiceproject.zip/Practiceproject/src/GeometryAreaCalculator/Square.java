package GeometryAreaCalculator;

public class Square {
	  // Overloaded function to
    // calculate the area of the square
    // It takes one double parameter
    void Area(double side)
    {
        System.out.println("Area of the Square: "+ side * side);
    }
    // Overloaded function to
    // calculate the area of the square
    // It takes one float parameter
    void Area(float side)
    {
        System.out.println("Area of the Square: "+ side * side);
    }
}

