import static org.junit.Assert.assertTrue;

import java.time.Month;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

public class Strings2
{

@ParameterizedTest

@EnumSource (Month.class) // passing all 12 months

void getValueForAMonth_IsAlwaysBetweenOneAndTwelve (Month month) {

int monthNumber = month.getValue();

assertTrue(monthNumber >= 1 && monthNumber <= 12);

}
}
