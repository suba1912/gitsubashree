import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.util.EnumSet;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

public class Demo1 {

    @ParameterizedTest
    @EnumSource(value = ElementType.class, names = { "TYPE", "METHOD", "FIELD" })
    void testEnumSourceExtended(ElementType et) {
        assertTrue(EnumSet.of(ElementType.FIELD, ElementType.TYPE, ElementType.METHOD).contains(et));
    }
}
