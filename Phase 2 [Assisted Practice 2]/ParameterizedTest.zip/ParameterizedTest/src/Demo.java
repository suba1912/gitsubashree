import static org.junit.Assert.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;

import org.junit.jupiter.params.provider.ValueSource;

public class Demo {

@ParameterizedTest

@ValueSource(ints = { 4, 5, 6 })

void test_ValueSource(int i) {

System.out.println(i);

}

@ParameterizedTest

@ValueSource(strings = { "4", "5", "6" })

void test_ValueSource_String(String s) { assertTrue(Integer.parseInt(s) < 5);
}
}