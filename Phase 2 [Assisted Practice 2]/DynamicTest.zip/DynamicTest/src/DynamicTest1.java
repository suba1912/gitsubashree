import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.function.Executable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.DynamicTest.dynamicTest;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class DynamicTest1 {

    public static class MyUtils {

        public static int add(int x, int y) {
            return x + y;
        }
    }

    @TestFactory
    Stream<DynamicTest> dynamicTestsEx() {
        List<Integer> inputList1 = Arrays.asList(1, 2, 3);
        List<Integer> inputList2 = Arrays.asList(10, 20, 30);

        List<DynamicTest> dynamicTests = new ArrayList<>();

        for (int i = 0; i < inputList1.size(); i++) {
            int x = inputList1.get(i);
            int y = inputList2.get(i);

            DynamicTest dynamicTest = dynamicTest("Test for MyUtils.add(" + x + "," + y + ")", () -> {
                inputVariables(x + y, MyUtils.add(x, y));
            });

            dynamicTests.add(dynamicTest);
        }

        return dynamicTests.stream();
    }

    private void inputVariables(int expected, int actual) {
        assertEquals(expected, actual);
    }

    public class MyExecutable implements Executable {
        @Override
        public void execute() throws Throwable {
            System.out.println("Dynamic test");
        }
    }
}

