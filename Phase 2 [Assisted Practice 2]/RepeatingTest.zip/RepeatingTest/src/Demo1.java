import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;

public class Demo1 {

    @RepeatedTest(5) // Change the value as needed
    void test_with_RepetitionInfo_Injection(RepetitionInfo repetitionInfo) {
        System.out.println("Number of executions");
        assertEquals(5, repetitionInfo.getTotalRepetitions());
        System.out.println("Current Test Count=" + repetitionInfo.getCurrentRepetition());
    }
}
