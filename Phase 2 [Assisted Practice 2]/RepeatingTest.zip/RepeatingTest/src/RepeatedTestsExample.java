import org.junit.jupiter.api.RepeatedTest;



public class RepeatedTestsExample {

    @RepeatedTest(5)

    void demo() {

        System.out.println("Welcome");

    }

}
