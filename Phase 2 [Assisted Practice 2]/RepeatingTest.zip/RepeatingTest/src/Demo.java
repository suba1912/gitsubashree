import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.TestInfo;
public class Demo {
@RepeatedTest(value=3,name="{displayName} {currentRepetition}/{totalRepetitions}")
@DisplayName("Exection")
void test_with_cutom_DisplayName(TestInfo testInfo)
{
	System.out.println(testInfo.getDisplayName());
}
}
