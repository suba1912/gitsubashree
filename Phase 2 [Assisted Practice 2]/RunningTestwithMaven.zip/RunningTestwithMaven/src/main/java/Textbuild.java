public class Textbuild {

    public static String getHelloWorld(){
        return "hello world";
    }
   public static int getNumber10(){
        return 10;
    }
}