
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Msgbuild {

    @Test
    public void testHelloWorld() {
        assertEquals("hello world", Textbuild.getHelloWorld());
    }

    @Test
    public void testNumber10() {
        assertEquals(10, Textbuild.getNumber10());
    }

}