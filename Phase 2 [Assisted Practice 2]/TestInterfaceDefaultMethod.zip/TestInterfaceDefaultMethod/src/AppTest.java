import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.stream.Stream;

public class AppTest {

    @TestFactory
    Stream<DynamicTest> dynamicTestsForPalindrome() {
        return Stream.of("racecar", "radar", "mom", "dad")
                .map(text -> dynamicTest(text, () -> assertTrue(isPalindrome(text))));
    }

    boolean isPalindrome(String text) {
        // Implement the logic to check if the given text is a palindrome
        String reversed = new StringBuilder(text).reverse().toString();
        return text.equals(reversed);
    }
}
