import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.ParameterContext;
import org.junit.jupiter.api.extension.ParameterResolver;

public class FraudserviceParameterResolver implements ParameterResolver {

    @Override
    public Object resolveParameter(
            ParameterContext parameterContext, ExtensionContext extensionContext) {
        // Your implementation to provide the parameter value
        return null; // Replace with your actual logic
    }

    @Override
    public boolean supportsParameter(
            ParameterContext parameterContext, ExtensionContext extensionContext) {
        // Your implementation to determine if this resolver supports the parameter
        return false; // Replace with your actual logic
    }
}
