public class FraudService {
    // Implement the FraudService class as needed
    // You can add methods, properties, etc., based on the actual functionality
    // For simplicity, let's assume a basic implementation

    public boolean checkFraud(String transactionId) {
        // Simulated fraud check logic
        // In a real-world scenario, this would involve more complex logic
        return transactionId.startsWith("fraud");
    }
}

