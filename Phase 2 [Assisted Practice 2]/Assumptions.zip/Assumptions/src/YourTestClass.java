import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assumptions.*;

public class YourTestClass {

    @ParameterizedTest
    @ValueSource(ints = {1, 2, 3, -1})
    void test(int i) {
        assumeTrue(i >= 1);
        try {
            Thread.sleep(i);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    void demo_assumeFalse() {
        assumeFalse("root".equals(System.getenv("USER")));
    }

    @Test
    void test_assumingThat() {
        assumingThat("James".equals(System.getenv("USER")), () -> {
            System.out.println("USER is James, continue further");
            // Additional test logic here
        });
    }
}
